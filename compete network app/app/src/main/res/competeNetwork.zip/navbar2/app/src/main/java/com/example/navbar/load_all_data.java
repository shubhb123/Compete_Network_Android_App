package com.example.navbar;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class load_all_data extends AppCompatActivity {
String name, comp, dead, dead_tym, fees, number, date, tym;
FirebaseAuth auth;
FirebaseDatabase db;
int img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_load_all_data);
        name=getIntent().getExtras().getString("key1");
        comp=getIntent().getExtras().getString("key2");
        img=getIntent().getExtras().getInt("key3");
        dead=getIntent().getExtras().getString("key4");
        dead_tym=getIntent().getExtras().getString("key5");
        fees=getIntent().getExtras().getString("key6");
        number=getIntent().getExtras().getString("key7");
        date=getIntent().getExtras().getString("key8");
        tym=getIntent().getExtras().getString("key9");
        fetchData();
    }
    void fetchData()
    {
        String userid = auth.getCurrentUser().getUid();
        DatabaseReference reference=db.getReference("listLoad").child(userid);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot: snapshot.getChildren()) {
                    listLoad value = snapshot.getValue(listLoad.class);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}