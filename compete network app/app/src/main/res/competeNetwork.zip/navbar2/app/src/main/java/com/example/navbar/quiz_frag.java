package com.example.navbar;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

/* *
 * A simple {@link Fragment} subclass.
 * Use the  factory method to
 * create an instance of this fragment.
 */
public class quiz_frag extends Fragment {
    TextView eventname,companyname;
    SearchView searchView;
    RecyclerView recycle;
    MyAdapter adapter;
    FirebaseAuth mAuth;
    FirebaseDatabase database;
    DatabaseReference reference;
    ArrayList<listLoad> list;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v=inflater.inflate(R.layout.fragment_all_frag, container, false);
        recycle=v.findViewById(R.id.recycler);
        list=new ArrayList<>();
        recycle.setLayoutManager(
                new LinearLayoutManager(getContext()));
        /* RecyclerView.LayoutManager manager=new LinearLayoutManager(getContext());
        recycle.setLayoutManager(manager); */
        list = new ArrayList<>();
        adapter = new MyAdapter(list, getContext());
        recycle.setAdapter(recycle.getAdapter());
        searchView=v.findViewById(R.id.search);
        eventname= v.findViewById(R.id.name);
        companyname= v.findViewById(R.id.des);

        mAuth = FirebaseAuth.getInstance();
        String uid= mAuth.getCurrentUser().getUid();
        reference = FirebaseDatabase.getInstance().getReference().child("userEvents").child(uid);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listLoad u= snapshot.getValue(listLoad.class);

                eventname.setText(u.getName());
                companyname.setText(u.getComp());

            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getContext(), "Not working"+error, Toast.LENGTH_SHORT).show();
            }

        });




        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                getAdapter().getFilter().filter(newText);
                return false;
            }
        });
        return v;
    }

    private MyAdapter getAdapter() {
        return adapter;
    }
    /* @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu_layout, menu);
        MenuItem searchItem= menu.findItem(R.id.search);
        SearchView searchView= (SearchView) searchItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            });
        } */
}