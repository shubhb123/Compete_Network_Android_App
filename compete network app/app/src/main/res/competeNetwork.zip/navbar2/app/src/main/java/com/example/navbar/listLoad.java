package com.example.navbar;

import android.widget.Button;

public class listLoad {
    String name,comp,dead,dead_tym,fees,number,date,tym;
    int img;
    Button btn;

    public listLoad(String name, String comp, String dead, String dead_tym, String fees, String number, String date, String tym) {
        this.name = name;
        this.comp = comp;
        this.dead = dead;
        this.dead_tym = dead_tym;
        this.fees = fees;
        this.number = number;
        this.date = date;
        this.tym = tym;
        this.img = img;
        this.btn = btn;
    }

    public listLoad() {
    }

    public String getName() {
        return name;
    }

    public String getComp() {
        return comp;
    }

    public String getDead() {
        return dead;
    }

    public String getDead_tym() {
        return dead_tym;
    }

    public String getFees() {
        return fees;
    }

    public String getNumber() {
        return number;
    }

    public String getDate() {
        return date;
    }

    public String getTym() {
        return tym;
    }

    public int getImg() {
        return img;
    }

    public Button getBtn() {
        return btn;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setComp(String comp) {
        this.comp = comp;
    }

    public void setDead(String dead) {
        this.dead = dead;
    }

    public void setDead_tym(String dead_tym) {
        this.dead_tym = dead_tym;
    }

    public void setFees(String fees) {
        this.fees = fees;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setTym(String tym) {
        this.tym = tym;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public void setBtn(Button btn) {
        this.btn = btn;
    }
}